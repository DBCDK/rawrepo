
DROP FUNCTION return_one();
