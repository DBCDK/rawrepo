
DROP TRIGGER test_table_trigger ON test_table;
