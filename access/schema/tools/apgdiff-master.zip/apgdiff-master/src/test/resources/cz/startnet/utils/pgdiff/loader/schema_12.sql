COMMENT ON DATABASE testdb IS 'The status : ''E'' for enabled, ''D'' for disabled.';
