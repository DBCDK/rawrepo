
DROP INDEX testindex3;
