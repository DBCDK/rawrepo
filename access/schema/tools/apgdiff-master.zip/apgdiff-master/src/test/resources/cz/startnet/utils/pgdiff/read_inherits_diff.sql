
ALTER TABLE testtable
	ADD COLUMN field2 information_schema.cardinal_number;
