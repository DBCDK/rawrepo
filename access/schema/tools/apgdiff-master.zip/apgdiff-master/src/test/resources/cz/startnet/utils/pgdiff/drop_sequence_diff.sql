
DROP SEQUENCE testseq;
