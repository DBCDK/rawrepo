
DROP TABLE testtable2;
