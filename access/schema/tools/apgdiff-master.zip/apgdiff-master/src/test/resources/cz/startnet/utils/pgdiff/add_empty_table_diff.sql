CREATE TABLE empty_table (
);