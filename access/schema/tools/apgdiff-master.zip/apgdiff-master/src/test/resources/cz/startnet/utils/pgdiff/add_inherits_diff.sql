
CREATE TABLE testtable (
	field1 polygon
)
INHERITS (parenttable);
