
DROP FUNCTION multiply_numbers(number2 smallint, number1 smallint);
