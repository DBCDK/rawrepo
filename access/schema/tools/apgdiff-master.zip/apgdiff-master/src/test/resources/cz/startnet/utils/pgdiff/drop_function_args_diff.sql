
DROP FUNCTION power_number("input" integer);
