
ALTER TABLE testtable
	ADD COLUMN field5 boolean DEFAULT false NOT NULL;
