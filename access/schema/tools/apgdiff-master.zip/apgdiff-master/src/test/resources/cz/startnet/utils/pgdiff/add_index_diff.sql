
CREATE INDEX testindex3 ON testtable USING btree (field3);
