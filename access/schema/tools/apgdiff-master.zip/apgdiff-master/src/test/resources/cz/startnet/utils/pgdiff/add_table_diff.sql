
CREATE TABLE testtable2 (
	id integer,
	name character varying(100) NOT NULL
);
