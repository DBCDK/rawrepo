
ALTER TABLE testtable
	DROP CONSTRAINT field4check;
