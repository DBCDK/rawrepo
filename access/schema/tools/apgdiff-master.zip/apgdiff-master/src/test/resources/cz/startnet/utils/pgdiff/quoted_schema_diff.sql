
SET search_path = "ABC", pg_catalog;

CREATE TABLE testtable2 (
	id integer,
	name character varying(100) NOT NULL
);
