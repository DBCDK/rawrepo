
ALTER TABLE testtable
	DROP COLUMN field5;
