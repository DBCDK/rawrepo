
DROP FUNCTION multiply_numbers(number1 integer, number2 integer);
