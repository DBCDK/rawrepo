
DROP INDEX testindex2;
