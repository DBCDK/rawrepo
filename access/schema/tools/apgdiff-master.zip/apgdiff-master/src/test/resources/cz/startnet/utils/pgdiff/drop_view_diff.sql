
DROP VIEW testview;
