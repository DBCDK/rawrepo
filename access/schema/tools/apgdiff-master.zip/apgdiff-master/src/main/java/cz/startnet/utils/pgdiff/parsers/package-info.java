/**
 * Parsers for parsing DDLs from PostgreSQL dumps.
 */
package cz.startnet.utils.pgdiff.parsers;
