/**
 * Contains tool that creates diff file from two PostgreSQL dump files.
 */
package cz.startnet.utils.pgdiff;
