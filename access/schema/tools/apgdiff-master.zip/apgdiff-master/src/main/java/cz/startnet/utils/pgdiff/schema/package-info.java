/**
 * Contains PostgreSQL schema objects.
 */
package cz.startnet.utils.pgdiff.schema;
